import json
import boto3
import urllib.parse
import os
import logging
from io import BytesIO
import pandas as pd
from botocore.config import Config
import uuid
import csv

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')
bedrock_agent_runtime = boto3.client(
    'bedrock-agent-runtime',
    region_name="us-west-2",
    config=Config(connect_timeout=10, read_timeout=120)
)

AGENT_ID = "QDTSICEWAF"
AGENT_ALIAS_ID = "ICRJF8TMZW"
HARD_CODED_TEMPLATE = "A10"

AGENT_FILENAME_VALIDATION_PROMPT = (
    "You will receive a file name and a template name. "
    "Your task is to validate whether the file name exists for the given template "
    "With same Agent (Template) multiple files will associated with it, so first look for the file name under column 'File Name' inside 'Agent File Specification' "
    "in the 'Agent File Specification' sheet under the 'File Name' column.Go through full column to match the file name"
    "If the file name matches for the template, return JSON: "
    '{"Validation": "Success", "InputFileName": "<the incoming file name>", "SpecifcationFileName": "<the file name from Agent File Specification>"} '
    "If not, return JSON: "
    '{"Validation": "Failed", "InputFileName": "<the incoming file name>", "SpecifcationFileName": "<the file name from Agent File Specification>"} '
    "Do not return any extra text or explanation."
)
# f"- Every standardized header from Output Field Specification (column 'Field Name') appears exactly once, in the same order as in the specification.\n"

# AGENT_HEADER_MAPPING_PROMPT = (
#     f"Instructions: You MUST return a JSON array where:\n"
#     f"- You are given REQUIRED standardized headers (SPEC_CHECKLIST). You MUST output them all, in the same order as given.\n"
#     f"- The total number of JSON objects MUST be >= the number of standardized headers present in the output specification file.\n"
#     f"- If a standardized header cannot be mapped, you MUST include it as:\n"
#     f'  {{\"inputHeader\": \"\", \"mappedHeader\": \"<Standardized_Header>\", \"confidenceScore\": 0}}\n'
#     f"- Never skip, drop, or omit any standardized header, even if no input mapping exists.\n\n"
#     f"Step 0: Build Checklists\n"
#     f"- DATA_CHECKLIST = all 'Input headers with data'\n"
#     f"- SPEC_CHECKLIST = all standardized headers from Output Field Specification\n\n"
#     f"Step 1: Alias Matching\n"
#     f"- For each input header, check if it exactly or fuzzily matches an alias in template \"{HARD_CODED_TEMPLATE}\".\n"
#     f"- Exact = confidenceScore 100, fuzzy = 80. Only one mappedHeader per spec header.\n\n"
#     f"Step 2: Self-Mapping for Data Headers ONLY\n"
#     f"- For each input header in DATA_CHECKLIST:\n"
#     f"   - If it maps to a standardized header → output the mapping.\n"
#     f"    -if it does NOT map to any standardized header but the headers is in DATA_CHEKLIST or is in Input Headers with Data -> output:"
#     f'     {{\"inputHeader\": \"<header>\", \"mappedHeader\": \"\", \"confidenceScore\": 0}}\n'
#     f"- IMPORTANT: Do NOT include any header that is not in DATA_CHECKLIST.\n\n"
#     f"Step 3: Placeholder Coverage\n"
#     f"- After Step 1 and Step 2, ensure every header from SPEC_CHECKLIST is present in the JSON in correct order.\n"
#     f"- If not mapped, add placeholder as described.\n\n"
#     f"Step 4: Append Extras\n"
#     f"- After placeholders, append any headers from DATA_CHECKLIST that were not already included.\n"
#     f"- Ignore all headers that are not in DATA_CHECKLIST.\n\n"
#     f"Final Verification (MANDATORY)\n"
#     f"- Count entries. It MUST be >= the number of standardized headers present in the specification file.\n"
#     f"- Confirm every SPEC_CHECKLIST header appears once.\n"
#     f"- Confirm every DATA_CHECKLIST header appears once.\n"
#     f"- Confirm NO header outside DATA_CHECKLIST is included unless it maps to a standardized header.\n"
#     f"- If any condition fails, regenerate before responding.\n\n"
#     f"Output: ONLY return the JSON array, in this order:\n"
#     f"1) All standardized headers (SPEC_CHECKLIST) in correct order\n"
#     f"2) Followed by any extra DATA_CHECKLIST headers."
# )

AGENT_HEADER_MAPPING_PROMPT = (
    f"Instructions: You MUST return a JSON array where:\n"
    f"- You are given REQUIRED standardized headers (SPEC_CHECKLIST). You MUST output them all, in the same order as given.\n"
    f"- The total number of JSON objects MUST be >= the number of standardized headers present in the output specification file.\n"
    f"- If a standardized header cannot be mapped, you MUST include it as:\n"
    f'  {{\"inputHeader\": \"\", \"mappedHeader\": \"<Standardized_Header>\", \"confidenceScore\": 0}}\n'
    f"- Never skip, drop, or omit any standardized header, even if no input mapping exists.\n\n"
    f"Step 0: Build Checklists\n"
    f"- DATA_CHECKLIST = all 'Input headers with data'\n"
    f"- SPEC_CHECKLIST = all standardized headers from Output Field Specification\n\n"
    f"Step 1: Alias Matching\n"
    f"- For each input header, check if it exactly or fuzzily matches an alias in template \"{HARD_CODED_TEMPLATE}\".\n"
    f"- Exact = confidenceScore 100, fuzzy = 80. Only one mappedHeader per spec header.\n\n"
    f"Step 2: Self-Mapping for Data Headers ONLY\n"
    f"- For each input header in DATA_CHECKLIST:\n"
    f"   - If it maps to a standardized header → output the mapping.\n"
    f"   - If it does NOT map to any standardized header but the header is in DATA_CHECKLIST "
    f"     or is in Input Headers with Data → output:\n"
    f'     {{\"inputHeader\": \"<header>\", \"mappedHeader\": \"\", \"confidenceScore\": 0}}\n'
    f"- IMPORTANT: Do NOT include any header that is not in DATA_CHECKLIST.\n\n"
    f"Step 3: Placeholder Coverage\n"
    f"- After Step 1 and Step 2, ensure every header from SPEC_CHECKLIST is present in the JSON in correct order.\n"
    f"- If not mapped, add placeholder as described.\n\n"
    f"Step 4: Append Extras\n"
    f"- After placeholders, append any headers from DATA_CHECKLIST that were not already included.\n"
    f"- Ignore all headers that are not in DATA_CHECKLIST.\n\n"
    f"Final Verification (MANDATORY)\n"
    f"- Count entries. It MUST be >= the number of standardized headers present in the specification file.\n"
    f"- Confirm every SPEC_CHECKLIST header appears once.\n"
    f"- Confirm every DATA_CHECKLIST header appears once.\n"
    f"- Confirm NO header outside DATA_CHECKLIST is included unless it maps to a standardized header.\n"
    f"- If any condition fails, regenerate before responding.\n\n"
    f"Output: ONLY return the JSON array, in this order:\n"
    f"1) All standardized headers (SPEC_CHECKLIST) in correct order\n"
    f"2) Followed by any extra DATA_CHECKLIST headers."
)


def get_standardized_headers():
    """
    Load standardized headers (SPEC_CHECKLIST) from KB Excel file in S3.
    Reads 'Output Field Specification' sheet, 'Field Name' column.
    """
    kb_bucket = "tns-ai-knowledgebase"
    kb_file_key = "SBI-Knowledgebase/SG_ingest_training_data.xlsx"

    try:
        s3_obj = s3.get_object(Bucket=kb_bucket, Key=kb_file_key)
        file_bytes = s3_obj['Body'].read()
        # Load Output Field Specification sheet, with header on 2nd row
        df_spec = pd.read_excel(
            BytesIO(file_bytes),
            sheet_name="Output Field Specification",
            header=1,  # 👈 Fix here
            dtype=str
        )

        if "Field Name" not in df_spec.columns:
            raise ValueError("Expected 'Field Name' column not found in Output Field Specification sheet")

        # Drop blanks and normalize
        headers = df_spec["Field Name"].dropna().map(str.strip).tolist()
        logger.info(f"[INFO] Loaded {len(headers)} standardized headers from KB file {kb_file_key}")
        return headers
    except Exception as e:
        logger.error(f"[ERROR] Failed to load standardized headers from KB file {kb_file_key}: {e}", exc_info=True)
        raise


# -------------------------------
# Detect delimiter (helper function)
# -------------------------------
def detect_file_delimiter(file_bytes, sample_size=5000):
    sample = file_bytes[:sample_size].decode("utf-8", errors="ignore")
    possible_delims = [",", "\t", "|", ";", ":", "~"]
    delim_counts = {d: sample.count(d) for d in possible_delims}
    detected = max(delim_counts, key=delim_counts.get)
    if delim_counts[detected] == 0:
        raise ValueError("No valid delimiter found in file!")
    logger.info(f"[INFO] Detected delimiter: '{detected}'")
    return detected


# -------------------------------
# Load file with dynamic delimiter
# -------------------------------
def load_file_once(file_bytes, file_extension):
    try:
        if file_extension in ['.csv', '.txt']:
            detected_delim = detect_file_delimiter(file_bytes)
            df = pd.read_csv(BytesIO(file_bytes), delimiter=detected_delim, dtype=str, keep_default_na=False)
        elif file_extension in ['.xls', '.xlsx']:
            df = pd.read_excel(BytesIO(file_bytes), dtype=str)
        else:
            raise ValueError(f"Unsupported file type: {file_extension}")
        headers = [str(col).strip() for col in df.columns]
        df.columns = headers
        logger.info(f"[INFO] Extracted headers: {headers}")
        return df, headers
    except Exception as e:
        logger.error(f"[ERROR] Reading file failed: {e}", exc_info=True)
        raise


# -------------------------------
# Extract headers with data
# -------------------------------
def extract_headers_with_data(df, headers):
    headers_with_data = []
    false_positives = []
    for col in headers:
        series = df[col].astype(str).str.strip().replace("nan", "").replace("", pd.NA)
        if series.notna().any():
            headers_with_data.append(col)
        else:
            false_positives.append(col)
    logger.info(f"Total headers: {len(headers)}")
    logger.info(f"Headers with data count: {len(headers_with_data)}")
    logger.info(f"Headers with data: {headers_with_data}")
    logger.info(f"Headers WITHOUT data (ignored): {false_positives}")
    return headers_with_data


# -------------------------------
# Invoke agent with payload
# -------------------------------
def invoke_agent(payload, session_id):
    params = {
        "agentId": AGENT_ID,
        "agentAliasId": AGENT_ALIAS_ID,
        "sessionId": session_id,
        "inputText": payload
    }
    response = bedrock_agent_runtime.invoke_agent(**params)
    chunks = []
    for event in response.get("completion", []):
        if "chunk" in event and "bytes" in event["chunk"]:
            chunks.append(event["chunk"]["bytes"].decode("utf-8"))
    full_output = "".join(chunks).strip()
    logger.info(f"Raw agent response: {full_output}")
    return full_output


# -------------------------------
# Create output Excel
# -------------------------------
def create_output_excel(mappings, input_data_df):
    df_out = pd.DataFrame()
    seen_mapped = set()
    for m in mappings:
        input_header = m.get("inputHeader", "").strip()
        mapped_header = m.get("mappedHeader", "").strip()
        col_name = mapped_header if mapped_header else input_header
        if not col_name or col_name in seen_mapped:
            continue
        seen_mapped.add(col_name)
        if input_header in input_data_df.columns:
            col_data = input_data_df[input_header]
            if col_name == "customerCountryCode":
                col_data = col_data.replace("", pd.NA).fillna("USA")
            elif col_name == "currencyCode":
                col_data = col_data.replace("", pd.NA).fillna("USD")
            df_out[col_name] = col_data
        else:
            if col_name == "customerCountryCode":
                df_out[col_name] = "USA"
            elif col_name == "currencyCode":
                df_out[col_name] = "USD"
            else:
                df_out[col_name] = ""
    output_stream = BytesIO()
    df_out.to_excel(output_stream, index=False, engine="openpyxl")
    output_stream.seek(0)
    return output_stream


# -------------------------------
# Lambda Handler
# -------------------------------
def lambda_handler(event, context):
    try:
        record = event['Records'][0]
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'])
        file_name = os.path.basename(key)
        template_name = HARD_CODED_TEMPLATE

        logger.info(f"Triggered by file: {key} in bucket: {bucket}")

        # Step 0: Validation
        validation_payload = f"File Name: {file_name}\nTemplate: {template_name}\n{AGENT_FILENAME_VALIDATION_PROMPT}"
        validation_response = invoke_agent(validation_payload, str(uuid.uuid4()))
        try:
            validation_result = json.loads(validation_response)
        except json.JSONDecodeError:
            logger.error("Invalid JSON from agent in validation step")
            return {'statusCode': 500, 'body': 'Invalid JSON from agent'}

        if validation_result.get("Validation") != "Success":
            logger.error(f"File validation failed for {file_name}.")
            return {'statusCode': 400, 'body': f"File validation failed for {file_name}"}

        # Step 1: Load file
        _, ext = os.path.splitext(key)
        ext = ext.lower()
        if ext not in ['.csv', '.xls', '.xlsx', '.txt']:
            return {'statusCode': 400, 'body': f"Unsupported file type {ext}"}
        s3_obj = s3.get_object(Bucket=bucket, Key=key)
        file_bytes = s3_obj['Body'].read()
        input_data_df, headers = load_file_once(file_bytes, ext)
        if not headers:
            return {'statusCode': 400, 'body': 'No headers extracted'}

        # Step 2: Extract headers with data
        headers_with_data = extract_headers_with_data(input_data_df, headers)
        logger.info(f"Headers with data: {headers_with_data}")

        spec_headers = get_standardized_headers()
        # Step 3: Retry loop for agent mapping
        mappings = []
        retries = 0
        max_retries = 2
        while retries <= max_retries:
            mapping_payload = (
                f"Template: {template_name}\n"
                f"Required standardized headers (SPEC_CHECKLIST): {json.dumps(spec_headers)}\n"
                f"Input headers: {json.dumps(headers)}\n"
                f"Input headers with data: {json.dumps(headers_with_data)}\n"
                f"{AGENT_HEADER_MAPPING_PROMPT}"
            )
            logger.info(f"Sending payload to agent:\n{mapping_payload.encode('unicode_escape').decode()}")
            logger.info("Attempt: %s", retries + 1)
            mapping_response = invoke_agent(mapping_payload, str(uuid.uuid4()))
            try:
                mappings = json.loads(mapping_response)
            except json.JSONDecodeError:
                logger.error("Invalid JSON from agent in mapping step")
                return {'statusCode': 500, 'body': 'Invalid JSON from agent'}

            logger.info(f"Parsed {len(mappings)} mappings")
            if len(mappings) >= 62:
                break
            retries += 1
            logger.warning(f"Retry {retries}/{max_retries}: Mappings less than 62, retrying...")

        if len(mappings) < 62:
            logger.error("Unable to extract sufficient mappings after retries")
            return {'statusCode': 500, 'body': 'Unable to extract sufficient mappings'}

        # Step 4: Post-processing mappings
        corrected_mappings = []
        seen_input_headers = set()
        seen_mapped_headers = set()
        for m in mappings:
            input_header = m.get("inputHeader", "").strip()
            mapped_header = m.get("mappedHeader", "").strip()
            if not input_header and not mapped_header:
                continue
            if input_header and input_header not in headers_with_data and not mapped_header:
                continue
            if mapped_header and mapped_header in seen_mapped_headers:
                continue
            if input_header and input_header in seen_input_headers:
                continue
            corrected_mappings.append(m)
            if input_header:
                seen_input_headers.add(input_header)
            if mapped_header:
                seen_mapped_headers.add(mapped_header)
        for h in headers_with_data:
            if h not in seen_input_headers:
                corrected_mappings.append({"inputHeader": h, "mappedHeader": "", "confidenceScore": 0})
                seen_input_headers.add(h)
        logger.info(f"Corrected mappings count: {len(corrected_mappings)}")
        logger.info(f"Corrected mappings:\n{json.dumps(corrected_mappings, indent=2)}")

        # Step 5: Generate output
        output_stream = create_output_excel(corrected_mappings, input_data_df)
        base_name = os.path.basename(key)
        name_split = base_name.rsplit('.', 1)
        output_file = f"{name_split[0]}_final.xlsx"
        output_key = f"output/{output_file}"
        s3.put_object(Bucket=bucket, Key=output_key, Body=output_stream.getvalue())
        logger.info(f"Output saved to {output_key}")

        return {'statusCode': 200, 'body': f"Processed {key}, output saved to {output_key}"}

    except Exception as e:
        logger.error(f"Error processing file: {e}", exc_info=True)
        return {'statusCode': 500, 'body': str(e)}
