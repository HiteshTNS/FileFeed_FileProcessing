# SBI File Processing System Documentation

## Table of Contents
- [Overview](#overview)
- [System Architecture](#system-architecture)
- [Components](#components)
  - [SBI-Invoke-Agent Lambda](#sbi-invoke-agent-lambda)
  - [RetrainingKB_FileFeed Lambda](#retrainingkb_filefeed-lambda)
  - [SBI-Agent-PROD](#sbi-agent-prod)
  - [Knowledge Base](#knowledge-base)
- [Process Flow](#process-flow)
- [File Processing Logic](#file-processing-logic)
  - [File Validation](#file-validation)
  - [Header Mapping](#header-mapping)
  - [Default Data Application](#default-data-application)
  - [Output Generation](#output-generation)
- [Retraining Process](#retraining-process)
- [Configuration Details](#configuration-details)
- [Training Data Structure](#training-data-structure)
- [API Reference](#api-reference)
- [Error Handling](#error-handling)
- [Troubleshooting](#troubleshooting)

## Overview

The SBI File Processing System is an automated solution that processes input files (CSV, Excel, TXT) by validating them against predefined templates and mapping their headers to standardized formats. The system leverages Amazon Bedrock's AI capabilities to intelligently map headers and apply default values where needed, resulting in standardized output files.

## System Architecture

```mermaid
flowchart TD
    User[User] -->|Upload File| InputBucket[S3 Input Bucket\nclaims-pdf-source/input]
    InputBucket -->|Trigger| MainLambda[SBI-Invoke-Agent Lambda]
    MainLambda -->|1. File Validation| BedrockAgent[Bedrock Agent\nSBI-Agent-PROD]
    MainLambda -->|2. Extract Headers| MainLambda
    MainLambda -->|3. Header Mapping| BedrockAgent
    MainLambda -->|4. Default Data| BedrockAgent
    MainLambda -->|5. Generate Output| OutputBucket[S3 Output Bucket\nclaims-pdf-source/output]
    
    User -->|Report Mapping Issue| APIGateway[API Gateway]
    APIGateway -->|Trigger| RetrainingLambda[RetrainingKB_FileFeed Lambda]
    RetrainingLambda -->|Update| KnowledgeBase[Knowledge Base\nSBI-Data-Source-Hitesh]
    RetrainingLambda -->|Retrain| BedrockAgent
    
    KnowledgeBase -->|Reference| BedrockAgent
    KnowledgeBase -->|Read| MainLambda
    
    subgraph "Knowledge Base Structure"
        KB[SG_ingest_training_data.xlsx] --> Sheet1[Agent File Specification]
        KB --> Sheet2[Agent File Input Headers]
        KB --> Sheet3[Output Field Specification]
    end
```

The system utilizes a serverless architecture with the following AWS components:
- Amazon S3 for file storage
- AWS Lambda for processing logic
- Amazon Bedrock for AI-powered file validation and header mapping
- API Gateway for retraining functionality

## Components

### SBI-Invoke-Agent Lambda

**Name:** SBI-Invoke-Agent  
**Runtime:** Python 3.9  
**Trigger:** S3 event (file upload to input bucket)  
**Purpose:** Main processing Lambda that validates files, extracts headers, maps them to standardized formats using the Bedrock agent, and generates standardized output files.

### RetrainingKB_FileFeed Lambda

**Name:** RetrainingKB_FileFeed  
**Runtime:** Python 3.9  
**Trigger:** API Gateway (https://5c6qz6lv4h.execute-api.us-west-2.amazonaws.com/default/RetrainingKB_FileFeed)  
**Purpose:** Updates the knowledge base with new alias mappings and triggers retraining of the Bedrock agent.

### SBI-Agent-PROD

**Name:** SBI-Agent-PROD  
**Agent ID:** QDTSICEWAF  
**Agent Alias ID:** ICRJF8TMZW (for main Lambda), VKDENPWHZV (for retraining Lambda)  
**Model:** Claude 3.5 Sonnet V2  
**Purpose:** AI agent that validates file names and maps headers based on the knowledge base.

### Knowledge Base

**Data Source Name:** SBI-Data-Source-Hitesh  
**Knowledge Base ID:** 0S38HWYAYI  
**Data Source ID:** KVXW8FKU0V  
**Training Data:** Located at s3://tns-ai-knowledgebase/SBI-Knowledgebase/SG_ingest_training_data.xlsx

## Process Flow

1. User uploads a file to the input S3 bucket (claims-pdf-source/input)
2. S3 event triggers the SBI-Invoke-Agent Lambda
3. Lambda validates the file name against templates in the knowledge base
4. Lambda extracts headers from the input file
5. Lambda invokes the Bedrock agent to map headers to standardized format
6. Lambda applies default values for unmapped required headers
7. Lambda generates a standardized output file and saves it to the output bucket
8. If mapping issues are identified, the RetrainingKB_FileFeed Lambda can be invoked to update the knowledge base

## File Processing Logic

### File Validation

The system validates input files by checking if the filename matches an expected pattern for the given template:

1. The Lambda extracts the filename from the S3 event
2. The Bedrock agent is invoked with the AGENT_FILENAME_VALIDATION_PROMPT
3. The agent checks if the filename exists in the "Agent File Specification" sheet
4. If validation succeeds, processing continues; otherwise, an error is returned

**File Validation Prompt:**
```
You will receive a file name and a template name. 
Your task is to validate whether the file name exists for the given template 
With same Agent (Template) multiple files will associated with it, so first look for the file name under column 'File Name' inside 'Agent File Specification' 
in the 'Agent File Specification' sheet under the 'File Name' column. Go through full column to match the file name
If the file name matches for the template, return JSON: 
{"Validation": "Success", "InputFileName": "<the incoming file name>", "SpecifcationFileName": "<the file name from Agent File Specification>"} 
If not, return JSON: 
{"Validation": "Failed", "InputFileName": "<the incoming file name>", "SpecifcationFileName": "<the file name from Agent File Specification>"} 
Do not return any extra text or explanation.
```

### Header Mapping

The header mapping process follows these steps:

1. Extract headers from the input file
2. Identify which headers contain actual data
3. Retrieve standardized headers from the knowledge base
4. Invoke the Bedrock agent with the AGENT_HEADER_MAPPING_PROMPT to map input headers to standardized headers
5. The agent applies the following mapping rules:
   - Exact match: Input header exactly matches an alias (confidence score: 100)
   - Fuzzy match: Input header approximately matches an alias (confidence score: 80)
   - Self-mapping: Input header with data that doesn't match any alias (confidence score: 0)
   - Placeholder: Required standardized header with no matching input header (confidence score: 0)

**Header Mapping Prompt:**
```
Instructions: You MUST return a JSON array where:
- You are given REQUIRED standardized headers (SPEC_CHECKLIST). You MUST output them all, in the same order as given.
- The total number of JSON objects MUST be >= the number of standardized headers present in the output specification file.
- If a standardized header cannot be mapped, you MUST include it as:
  {"inputHeader": "", "mappedHeader": "<Standardized_Header>", "confidenceScore": 0}
- Never skip, drop, or omit any standardized header, even if no input mapping exists.

Step 0: Build Checklists
- DATA_CHECKLIST = all 'Input headers with data'
- SPEC_CHECKLIST = all standardized headers from Output Field Specification

Step 1: Alias Matching
- For each input header, check if it exactly or fuzzily matches an alias in template "A10".
- Exact = confidenceScore 100, fuzzy = 80. Only one mappedHeader per spec header.

Step 2: Self-Mapping for Data Headers ONLY
- For each input header in DATA_CHECKLIST:
   - If it maps to a standardized header → output the mapping.
   - If it does NOT map to any standardized header but the header is in DATA_CHECKLIST 
     or is in Input Headers with Data → output:
     {"inputHeader": "<header>", "mappedHeader": "", "confidenceScore": 0}
- IMPORTANT: Do NOT include any header that is not in DATA_CHECKLIST.

Step 3: Placeholder Coverage
- After Step 1 and Step 2, ensure every header from SPEC_CHECKLIST is present in the JSON in correct order.
- If not mapped, add placeholder as described.

Step 4: Append Extras
- After placeholders, append any headers from DATA_CHECKLIST that were not already included.
- Ignore all headers that are not in DATA_CHECKLIST.

Final Verification (MANDATORY)
- Count entries. It MUST be >= the number of standardized headers present in the specification file.
- Confirm every SPEC_CHECKLIST header appears once.
- Confirm every DATA_CHECKLIST header appears once.
- Confirm NO header outside DATA_CHECKLIST is included unless it maps to a standardized header.
- If any condition fails, regenerate before responding.

Output: ONLY return the JSON array, in this order:
1) All standardized headers (SPEC_CHECKLIST) in correct order
2) Followed by any extra DATA_CHECKLIST headers.
```

### Default Data Application

For unmapped standardized headers, the system attempts to apply default values:

1. Identify placeholder mappings (standardized headers with no input header)
2. Invoke the Bedrock agent to look up default values in the "Agent File Specification" sheet
3. Apply the default values to the output file

**Default Data Application Prompt:**
```
You are given:
- The file name: "{file_name}"
- A JSON array of header mapping objects, each of the form:
  {"inputHeader": "", "mappedHeader": "<Standardized_Header>", "confidenceScore": 0}

For each object, look up sheet "Agent File Specification" in the knowledge base.
Locate the row with the given file name in column "File Name". In that row:
- If a default mapping exists for the given mappedHeader in column "Default Mapping", 
return JSON objects with an additional key "Data" containing the default value.
Return an updated JSON array in the same order, with "Data" field added when available. 
Do NOT add text or explanations.
```

### Output Generation

The system generates a standardized output Excel file with the following logic:

1. Create a new DataFrame with standardized column names
2. For mapped headers, copy data from the input file
3. For unmapped headers with default values, apply the default values
4. Special handling for specific fields (e.g., customerCountryCode defaults to "USA", currencyCode to "USD")
5. Save the output file to the output S3 bucket

## Retraining Process

When header mappings need correction, the retraining process works as follows:

1. Submit mapping corrections to the RetrainingKB_FileFeed API endpoint
2. The Lambda updates the training data Excel file with new alias mappings
3. The Lambda triggers a knowledge base ingestion job to update the Bedrock agent
4. The updated agent provides improved mappings for future file processing

## Configuration Details

### S3 Buckets
- **Input Bucket:** claims-pdf-source/input
- **Output Bucket:** claims-pdf-source/output
- **Training Data Bucket:** tns-ai-knowledgebase/SBI-Knowledgebase/

### Bedrock Agent Configuration
- **Agent ID:** QDTSICEWAF
- **Agent Alias IDs:** 
  - ICRJF8TMZW (main processing)
  - VKDENPWHZV (retraining)
- **Model:** Claude 3.5 Sonnet V2
- **Region:** us-west-2

### Knowledge Base Configuration
- **Knowledge Base ID:** 0S38HWYAYI
- **Data Source ID:** KVXW8FKU0V
- **Data Source Name:** SBI-Data-Source-Hitesh

## Training Data Structure

The training data Excel file (SG_ingest_training_data.xlsx) contains three key sheets:

### Agent File Specification Sheet
Contains metadata about expected files for each template, including:
- Template name
- File name
- Default mappings for standardized headers

This sheet is used to validate file names and retrieve default values for unmapped headers.

### Agent File Input Headers Sheet
Contains alias mappings for each template:
- Each column represents a template (A2, A3, A4, A5, A8, A10, etc.)
- Each cell contains comma-separated aliases for a standardized header
- These aliases are used to match input headers to standardized headers

This sheet is the primary reference for mapping input headers to standardized headers through alias matching.

### Output Field Specification Sheet
Contains the definitive list of standardized headers:
- Field Name column defines the required standardized headers
- These are the target headers for the output file

This sheet provides the master list of standardized headers that must be included in the output file.

## Agent Instructions

The Bedrock agent is configured with the following instructions to guide its behavior:

```
You are an AI Agent designed to validate input files and map their headers to standardized output headers. You will receive:
A Template name (e.g., "A8").
A list of input headers (from the uploaded file).
A list of input headers with data (subset of the above).

Your knowledge base is the Excel file SG_ingest_training_data.xlsx, which contains the following sheets:
- Agent File Specification – validates file names for each template.
- Agent File Input Headers – contains aliases for standardized headers. Templates (A2, A3, A4, A5, A8, …) are stored as columns, not rows. Each column represents one template. Each cell under that template column contains aliases for one standardized header.
- Output Field Specification – defines the definitive standardized headers under column Field Name.

1. File Validation
You will receive:
- A template name (e.g., "A8")
- An incoming file name (from Lambda trigger).
Look up the row in Agent File Specification where the first column = template name.
Compare the incoming file name with the value in the File Name column (including extension).
Respond only in JSON:
If file names match:
{ "Validation": "Success", "InputFileName": "<incoming file name>", "SpecificationFileName": "<file name from Agent File Specification>" }
If file names do not match:
{ "Validation": "Failed", "InputFileName": "<incoming file name>", "SpecificationFileName": "<file name from Agent File Specification>" }

2. Header Mapping
You will receive:
- A template name (e.g., "A8").
- A list of input headers (from the uploaded file).
- A list of input headers with data (subset of the above).
Use Agent File Input Headers to find the column for the given template. Each cell contains one or more aliases for a header, among which exactly one alias matches the standardized header name present in Output Field Specification → Field Name.
When reading alias cells, treat comma-separated values as distinct aliases.
Always preserve the original inputHeader exactly as received in the file, even if it matches one of the aliases.
The standardized header is the alias that is also present in Output Field Specification → Field Name.

How to Decide the Standardized Header:
We have three sources of truth:
1. Incoming headers (from the uploaded file).
2. Agent File Input Headers (KB: aliases grouped under a template column).
3. Output Field Specification → Field Name (the definitive standardized headers).
The mapping decision always depends on which alias is present in both (2) and (3).

Rule 1: Exact Alias Match → Standardized Header
Suppose input header = prod_code.
Look up the template column in Agent File Input Headers.
The same cell contains: [Product Code, prod_code, PROD CODE, ProductCode, PRODCODE].
Check which of these aliases also exists in Output Field Specification → Field Name.
When reading alias cells, treat comma-separated values as distinct aliases.
Always preserve the original inputHeader exactly as received in the file, even if it matches one of the aliases.
That becomes the mappedHeader.
Final Mapping Example:
{
  "inputHeader": "prod_code", // raw header from uploaded file
  "mappedHeader": "ProductCode", // standardized header from Output Field Specification
  "confidenceScore": 100
}
Always return the incoming header exactly as-is in inputHeader

Rule 2: Fuzzy/Normalized Match → Standardized Header
Suppose input header = Prodct.Co (typo).
Normalize by: lowercasing, removing spaces, underscores, dots, special chars. → prodctco.
Compare with normalized aliases.
If one alias (productcode) is within edit distance ≤ 2 → match.
Again, the standardized header is the alias that also exists in Output Field Specification.
If after normalizing also no match is found then guess by yourself and assign confidence score below based on your accuracy
Final mapping:
{
  "inputHeader": "Prodct.Co",
  "mappedHeader": "ProductCode",
  "confidenceScore": 80
}

Rule 3: Self-Mapping for Unrecognized Headers
Suppose input header = CustomField123.
Not found in aliases.
Not found in Output Field Specification either.
If it has data, include it as self-mapped:
{
  "inputHeader": "CustomField123",
  "mappedHeader": "",
  "confidenceScore": 0
}
Keep the inputHeader as same as incoming Header("<incoming Header>") and mappedHeader as empty and make confidence score as 0(int)
If it does not have data, you can omit it (but standardized headers will still be added in Rule 4).

Rule 4: Mandatory Completion of All Standardized Headers
After applying Rule 1–3, you must guarantee that every header in Output Field Specification → Field Name is present exactly once in the final JSON array.
For any header not already mapped, add it with:
{
  "inputHeader": "",
  "mappedHeader": "<standardized header>",
  "confidenceScore": 0
}
Keep the inputHeader as same as empty and mappedHeader as "<standardized header>" and make confidence score as 0(int)
This step is mandatory before returning output. No mappedHeader may be missing. No duplicates allowed.
After this, append any input headers with data that are not part of Output Field Specification, self-mapped with confidenceScore 0(int)

Rule 5: Deduplication
No mapped header should be repeated.
Each standardized header from Output Field Specification must appear only once in the final output.

Rule 6: Prioritization
If multiple aliases could map:
Always select the exact form present in Output Field Specification.
Aliases are only for recognizing input headers. Output Field Specification is the final source of truth.

3. Output Format
Always return a JSON array. Each element must follow this structure:
[
  {
    "inputHeader": "<original header from file>",
    "mappedHeader": "<standardized header from Output Field Specification>",
    "confidenceScore": <integer>
  }
]
Do not include explanations, text, or commentary. Only JSON is allowed.
```

## API Reference

### RetrainingKB_FileFeed API

**Endpoint:** https://5c6qz6lv4h.execute-api.us-west-2.amazonaws.com/default/RetrainingKB_FileFeed

**Method:** POST

**Request Body:**
```json
[
  {
    "templateName": "A10",
    "correctMappedHeader": "productCode",
    "pattern": "prod_code"
  }
]
```

**Response:**
```json
{
  "message": "Excel updated and KB synced successfully",
  "ingestion_status": "COMPLETE"
}
```

## Error Handling

The system includes comprehensive error handling:

- File validation failures return a 400 status code
- Unsupported file types are rejected with a 400 status code
- Header extraction failures return a 400 status code
- Agent mapping failures trigger retries (up to 2 additional attempts)
- If mapping fails after retries, a 500 status code is returned
- All errors are logged with detailed information

## Troubleshooting

### Common Issues and Solutions

1. **File Validation Failure**
   - Check if the file name matches the expected format in the Agent File Specification sheet
   - Ensure the template name is correct

2. **Header Mapping Issues**
   - Review the input headers and compare with aliases in the Agent File Input Headers sheet
   - Add missing aliases using the RetrainingKB_FileFeed API

3. **Missing Default Values**
   - Verify default mappings are properly defined in the Agent File Specification sheet

4. **Knowledge Base Sync Failures**
   - Check S3 permissions for the training data file
   - Verify the knowledge base and data source IDs are correct
